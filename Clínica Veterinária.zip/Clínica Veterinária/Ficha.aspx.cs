﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Ficha : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


            VETERINARIO.Camadas.BLL.Ficha bllFicha = new VETERINARIO.Camadas.BLL.Ficha();

            GridView1.DataSource = bllFicha.Select();
            GridView1.DataBind();

            Cache["OP"] = "X";
            habilitaCampos(false);
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblStatus.Text = DropDownList1.SelectedItem.Text;
    }

    protected void habilitaCampos(bool status)
    {
        if (Cache["OP"].ToString() != "E")
        {
            lblId.Text = "";
            lblIdAtendimento.Text = "";
            lblStatus.Text = "";
        }




        btnInseir.Enabled = !status;
        btnEditar.Enabled = !status;
        btnGravar.Enabled = status;



    }

    protected void btnInseir_Click(object sender, EventArgs e)
    {
        Cache["OP"] = "I";
        habilitaCampos(true);
        lblId.Text = "-1";
        lblIdAtendimento.Focus();
    }

    protected void btnGravar_Click(object sender, EventArgs e)
    {
        VETERINARIO.Camadas.BLL.Ficha bllFicha = new VETERINARIO.Camadas.BLL.Ficha();
        VETERINARIO.Camadas.MODEL.Ficha_Vet Ficha = new VETERINARIO.Camadas.MODEL.Ficha_Vet();

        Ficha.id = Convert.ToInt32(lblId.Text);
        Ficha.atendimento_id = Convert.ToInt32(lblIdAtendimento.Text);
        Ficha.status = lblStatus.Text;

        if (Cache["OP"].ToString() == "I")
            bllFicha.Insert(Ficha);
        else if (Cache["OP"].ToString() == "E")
            bllFicha.Update(Ficha);


        GridView1.DataSource = bllFicha.Select();
        GridView1.DataBind();

        if (Cache["OP"].ToString() == "I")
            GridView1.SetPageIndex(GridView1.PageCount);


        Cache["OP"] = "X";
        habilitaCampos(false);
    }

    protected void btnEditar_Click(object sender, EventArgs e)
    {
        if (lblId.Text != String.Empty)
            if (Convert.ToInt32(lblId.Text) > 0)
            {
                Cache["OP"] = "E";
                habilitaCampos(true);
                lblIdAtendimento.Focus();
            }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {
            GridViewRow linha = GridView1.Rows[Convert.ToInt32(e.CommandArgument)];
            lblId.Text = linha.Cells[1].Text;

        }
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        VETERINARIO.Camadas.BLL.Ficha bllFicha = new VETERINARIO.Camadas.BLL.Ficha();
        GridView1.DataSource = bllFicha.Select();
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }

    protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {
            GridViewRow linha = GridView2.Rows[Convert.ToInt32(e.CommandArgument)];
            lblIdAtendimento.Text = linha.Cells[1].Text;

        }
    }
}