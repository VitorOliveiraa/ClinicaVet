﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class CadastroCliente : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


            VETERINARIO.Camadas.BLL.Cliente bllCliente = new VETERINARIO.Camadas.BLL.Cliente();

            GridView1.DataSource = bllCliente.Select();
            GridView1.DataBind();

            Cache["OP"] = "X";
            habilitaCampos(false);
        }
    }
    protected void habilitaCampos(bool status)
    {
        if (Cache["OP"].ToString() != "E")
        {
            Label1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
        }

        TextBox2.Enabled = status;
        TextBox3.Enabled = status;
        TextBox4.Enabled = status;
        TextBox5.Enabled = status;
        TextBox6.Enabled = status;

        btnInserir.Enabled = !status;
        btnEditar.Enabled = !status;
        brtRemover.Enabled = !status;
        btnGravar.Enabled = status;
        btnCancelar.Enabled = status;


    }

    protected void btnInserir_Click(object sender, EventArgs e)
    {
    }

    protected void btnEditar_Click(object sender, EventArgs e)
    {

    }

    protected void btnInserir_Click1(object sender, EventArgs e)
    {
        Cache["OP"] = "I";
        habilitaCampos(true);
        Label1.Text = "-1";
        TextBox2.Focus();
    }

    protected void btnCancelar_Click(object sender, EventArgs e)
    {
        Cache["OP"] = "X";
        habilitaCampos(false);
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        VETERINARIO.Camadas.BLL.Cliente bllCliente = new VETERINARIO.Camadas.BLL.Cliente();
        GridView1.DataSource = bllCliente.Select();
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }

    protected void btnGravar_Click(object sender, EventArgs e)
    {
        VETERINARIO.Camadas.BLL.Cliente bllCliente = new VETERINARIO.Camadas.BLL.Cliente();
        VETERINARIO.Camadas.MODEL.Cliente_Vet cliente = new VETERINARIO.Camadas.MODEL.Cliente_Vet();

        cliente.id = Convert.ToInt32(Label1.Text);
        cliente.nome = TextBox2.Text;
        cliente.cpf = Convert.ToDecimal(TextBox3.Text);
        cliente.fone = Convert.ToDecimal(TextBox4.Text);
        cliente.endereco = TextBox5.Text;
        cliente.cidade = TextBox6.Text;

        if (Cache["OP"].ToString() == "I")
            bllCliente.Insert(cliente);
        else if (Cache["OP"].ToString() == "E")
            bllCliente.Update(cliente);


        GridView1.DataSource = bllCliente.Select();
        GridView1.DataBind();

        if (Cache["OP"].ToString() == "I")
            GridView1.SetPageIndex(GridView1.PageCount);


        Cache["OP"] = "X";
        habilitaCampos(false);

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {
            GridViewRow linha = GridView1.Rows[Convert.ToInt32(e.CommandArgument)];
            Label1.Text =   linha.Cells[1].Text;
            TextBox2.Text = linha.Cells[2].Text;
            TextBox3.Text = linha.Cells[3].Text;
            TextBox4.Text = linha.Cells[4].Text;
            TextBox5.Text = linha.Cells[5].Text;
            TextBox6.Text = linha.Cells[6].Text;
        }
    }

    protected void btnEditar_Click1(object sender, EventArgs e)
    {
        if (Label1.Text != String.Empty)
            if (Convert.ToInt32(Label1.Text) > 0)
            {
                Cache["OP"] = "E";
                habilitaCampos(true);
                TextBox2.Focus();
            }
        
    }
    protected void brtRemover_Click(object sender, EventArgs e)
    {
        if (Label1.Text != String.Empty)
            if (Convert.ToInt32(Label1.Text) > 0)
            {

                VETERINARIO.Camadas.BLL.Cliente bllCliente = new VETERINARIO.Camadas.BLL.Cliente();
                VETERINARIO.Camadas.MODEL.Cliente_Vet cliente = new VETERINARIO.Camadas.MODEL.Cliente_Vet();

                cliente.id = Convert.ToInt32(Label1.Text);
                bllCliente.Delete(cliente);

                GridView1.DataSource = bllCliente.Select();
                GridView1.DataBind();

                Cache["OP"] = "X";
                habilitaCampos(false);
    

            }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}