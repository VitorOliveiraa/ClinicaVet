﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Atendimentos : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


            VETERINARIO.Camadas.BLL.Atendimento bllAtendimento = new VETERINARIO.Camadas.BLL.Atendimento();

            GridView1.DataSource = bllAtendimento.Select();
            GridView1.DataBind();

            Cache["OP"] = "X";
            habilitaCampos(false);
        }
    }
    protected void habilitaCampos(bool status)
    {
        if (Cache["OP"].ToString() != "E")
        {
            lblId.Text = "";
            TextBox1.Text = "";
            TextBox2.Text = "";
        }

        TextBox1.Enabled = status;
        TextBox2.Enabled = status;


        btnInserir.Enabled = !status;
        btnEditar.Enabled = !status;
        btnRemover.Enabled = !status;
        btnGravar.Enabled = status;
        btnCancelar.Enabled = status;


    }

    protected void btnInserir_Click(object sender, EventArgs e)
    {
        Cache["OP"] = "I";
        habilitaCampos(true);
        lblId.Text = "-1";
        TextBox1.Focus();

    }

    protected void btnCancelar_Click(object sender, EventArgs e)
    {
        Cache["OP"] = "X";
        habilitaCampos(false);
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        VETERINARIO.Camadas.BLL.Atendimento bllAtendimento = new VETERINARIO.Camadas.BLL.Atendimento();
        GridView1.DataSource = bllAtendimento.Select();
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }

    protected void btnGravar_Click(object sender, EventArgs e)
    {
        VETERINARIO.Camadas.BLL.Atendimento bllAtendimento = new VETERINARIO.Camadas.BLL.Atendimento();
        VETERINARIO.Camadas.MODEL.Atendimento_Vet Atendimento = new VETERINARIO.Camadas.MODEL.Atendimento_Vet();

        Atendimento.id = Convert.ToInt32(lblId.Text);
        Atendimento.animal_id = Convert.ToInt32(TextBox1.Text);
        Atendimento.data = Convert.ToDateTime(TextBox2.Text);

        if (Cache["OP"].ToString() == "I")
            bllAtendimento.Insert(Atendimento);
        else if (Cache["OP"].ToString() == "E")
            bllAtendimento.Update(Atendimento);


        GridView1.DataSource = bllAtendimento.Select();
        GridView1.DataBind();

        if (Cache["OP"].ToString() == "I")
            GridView1.SetPageIndex(GridView1.PageCount);


        Cache["OP"] = "X";
        habilitaCampos(false);
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {
            GridViewRow linha = GridView1.Rows[Convert.ToInt32(e.CommandArgument)];

            lblId.Text = linha.Cells[1].Text;
            TextBox1.Text = linha.Cells[2].Text;
            TextBox2.Text = linha.Cells[3].Text;

        }
    }

    protected void btnEditar_Click(object sender, EventArgs e)
    {
        if (lblId.Text != String.Empty)
            if (Convert.ToInt32(lblId.Text) > 0)
            {
                Cache["OP"] = "E";
                habilitaCampos(true);
                TextBox2.Focus();
            }

    }

    protected void btnRemover_Click(object sender, EventArgs e)
    {
        if (lblId.Text != String.Empty)
            if (Convert.ToInt32(lblId.Text) > 0)
            {

                VETERINARIO.Camadas.BLL.Atendimento bllAtendimento = new VETERINARIO.Camadas.BLL.Atendimento();
                VETERINARIO.Camadas.MODEL.Atendimento_Vet Atendimento = new VETERINARIO.Camadas.MODEL.Atendimento_Vet();

                Atendimento.id = Convert.ToInt32(lblId.Text);
                bllAtendimento.Delete(Atendimento);

                GridView1.DataSource = bllAtendimento.Select();
                GridView1.DataBind();

                Cache["OP"] = "X";
                habilitaCampos(false);

            }
    }

    protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {
            GridViewRow linha = GridView2.Rows[Convert.ToInt32(e.CommandArgument)];
            TextBox1.Text = linha.Cells[1].Text;

        }
    
}
}