﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO.Camadas.MODEL
{
    public class Cliente_Vet
    {

        public int id { get; set; }
        public string nome { get; set; }
        public decimal cpf { get; set; }
        public decimal fone { get; set; }
        public string endereco { get; set; }
        public string cidade { get; set; }

    
    }
}
