﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO.Camadas.MODEL
{
    public class Atendimento_Vet
    {
        public int id { get; set; }
        public int animal_id { get; set; }
        public DateTime data { get; set; }
        
    }
}

