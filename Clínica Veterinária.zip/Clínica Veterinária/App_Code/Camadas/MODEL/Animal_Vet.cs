﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO.Camadas.MODEL
{
    public class Animal_Vet
    {
        public int id { get; set; }
        public string nome { get; set; }
        public int idade { get; set; }
        public string raca { get; set; }
        public string cor { get; set; }
        public decimal peso { get; set; }
    }
}
