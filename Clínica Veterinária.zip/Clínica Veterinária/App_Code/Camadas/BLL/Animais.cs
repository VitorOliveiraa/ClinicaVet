﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO.Camadas.BLL
{
    public class Animais
    {
        public List<MODEL.Animal_Vet> Select()
        {
            DAL.Animais dalAni = new DAL.Animais();
            return dalAni.Select();
        }

        public List<MODEL.Animal_Vet> SelectById(int id)
        {
            DAL.Animais dalAni = new DAL.Animais();

            return dalAni.SelectById(id);
        }

        public List<MODEL.Animal_Vet> SelectByNome(string nome)
        {
            DAL.Animais dalAni = new DAL.Animais();

            return dalAni.SelectByNome(nome);
        }


        public void Insert(MODEL.Animal_Vet animal)
        {
            DAL.Animais dalAni = new DAL.Animais();
            dalAni.Insert(animal);

        }
        public void Update(MODEL.Animal_Vet animal)
        {
            DAL.Animais dalAni = new DAL.Animais();
            dalAni.Update(animal);
        }
        public void Delete(MODEL.Animal_Vet animal)
        {
            DAL.Animais dalAni = new DAL.Animais();
            dalAni.Delete(animal);
        }
    }
}
