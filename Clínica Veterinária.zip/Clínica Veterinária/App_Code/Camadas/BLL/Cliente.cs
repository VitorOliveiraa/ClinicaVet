﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO.Camadas.BLL
{
    public class Cliente
    {
        public List<MODEL.Cliente_Vet> Select()
        {
            DAL.Cliente dalCli = new DAL.Cliente ();
            return dalCli.Select();
        }
        public List<MODEL.Cliente_Vet> SelectById(int id)
        {
            DAL.Cliente dalCli = new DAL.Cliente();

            return dalCli.SelectById(id);
        }

        public List<MODEL.Cliente_Vet> SelectByNome(string nome)
        {
            DAL.Cliente dalCli = new DAL.Cliente();

            return dalCli.SelectByNome(nome);
        }

        public void Insert(MODEL.Cliente_Vet cliente)
        {
            DAL.Cliente dalCli = new DAL.Cliente();
            dalCli.Insert(cliente);

        }
           public void Update (MODEL.Cliente_Vet cliente)
        {
            DAL.Cliente dalCli = new DAL.Cliente();
            dalCli.Update(cliente);
        }
           public void Delete (MODEL.Cliente_Vet cliente)
        {
            DAL.Cliente dalCli = new DAL.Cliente();
            dalCli.Delete(cliente);
        }
    }
}
