﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO.Camadas.BLL
{
    public class Atendimento
    {
       
            public List<MODEL.Atendimento_Vet> Select()
            {
                DAL.Atendimento_Vet atendimento = new DAL.Atendimento_Vet();

                return atendimento.Select();
            }

            public void Insert(MODEL.Atendimento_Vet atendimento)
            {
                DAL.Atendimento_Vet Atendimento = new DAL.Atendimento_Vet();
               
                Atendimento.Insert(atendimento);
            }

            public void Update(MODEL.Atendimento_Vet atendimento)
            {
                DAL.Atendimento_Vet Atendimento = new DAL.Atendimento_Vet();
                Atendimento.Update(atendimento);
            }

            public void Delete(MODEL.Atendimento_Vet atendimento)
            {
                DAL.Atendimento_Vet Atendimento = new DAL.Atendimento_Vet();

                Atendimento.Delete(atendimento);
            }
        }
}
