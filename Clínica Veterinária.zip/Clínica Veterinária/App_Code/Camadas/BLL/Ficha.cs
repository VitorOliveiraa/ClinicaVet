﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO.Camadas.BLL
{
   public class Ficha
    {
        public List<MODEL.Ficha_Vet> Select()
        {
            DAL.Ficha_Vet dalficha = new DAL.Ficha_Vet();

            return dalficha.Select();
        }

        public List<MODEL.Ficha_Vet> SelectByFicha(int idAtendimento)
        {
            DAL.Ficha_Vet dalficha = new DAL.Ficha_Vet();

            return dalficha.SelectByFicha(idAtendimento);
        }

        public void Insert(MODEL.Ficha_Vet ficha)
        {
            DAL.Ficha_Vet dalficha = new DAL.Ficha_Vet();
            //
            dalficha.Insert(ficha);
        }

        public void Update(MODEL.Ficha_Vet ficha)
        {
            DAL.Ficha_Vet dalficha = new DAL.Ficha_Vet();
            dalficha.Update(ficha);
        }

        public void Delete(MODEL.Ficha_Vet ficha)
        {
            DAL.Ficha_Vet dalficha = new DAL.Ficha_Vet();

            dalficha.Delete(ficha);
        }
    }
}
