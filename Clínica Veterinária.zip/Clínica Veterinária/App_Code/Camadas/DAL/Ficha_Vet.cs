﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO.Camadas.DAL
{
    public class Ficha_Vet
    {
        private string strCon = Conexao.getConexao();

        public List<MODEL.Ficha_Vet> Select()

        { 
            List<MODEL.Ficha_Vet> lstFicha = new List<MODEL.Ficha_Vet>();
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Select * from Ficha_Vet";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            conexao.Open();

            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    MODEL.Ficha_Vet ficha = new MODEL.Ficha_Vet();
                    ficha.id = Convert.ToInt32(reader[0].ToString());
                    ficha.atendimento_id = Convert.ToInt32(reader["atendimento_id"].ToString());
                    ficha.status = reader["status"].ToString();


                    lstFicha.Add(ficha);
                }
            }
            catch
            {
                Console.WriteLine("Deu erro na Seleção de Ficha_Vet...");
            }
            finally
            {
                conexao.Close();
            }

            return lstFicha;
        }
        public List<MODEL.Ficha_Vet> SelectByFicha (int idAtendimento)
        {
            List<MODEL.Ficha_Vet> lstficha = new List<MODEL.Ficha_Vet>();
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Select * from Ficha_Vet where atendimento_id=@idAtendimento";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@idAtendimento", idAtendimento);
            conexao.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    MODEL.Ficha_Vet ficha = new MODEL.Ficha_Vet();
                    ficha.id = Convert.ToInt32(reader[0].ToString());
                    ficha.atendimento_id = Convert.ToInt32(reader["atendimento_id"].ToString());
                    ficha.status = reader["status"].ToString();
                   

                    lstficha.Add(ficha);
                }
            }
            catch
            {
                Console.WriteLine("Deu erro na Seleção de Ficha...");
            }
            finally
            {
                conexao.Close();
            }

            return lstficha;
        }
        public void Insert(MODEL.Ficha_Vet Ficha)
        {
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Insert into Ficha_Vet values (@atendimento_id, @status);";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@atendimento_id", Ficha.atendimento_id);
            cmd.Parameters.AddWithValue("@status", Ficha.status);
            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Deu erro na inserção de Ficha...");
            }
            finally
            {
                conexao.Close();
            }
        }

        public void Update(MODEL.Ficha_Vet ficha)
        {
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Update Ficha_Vet set atendimento_id=@atendimento_id, ";
            sql += "  status=@status where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", ficha.id);
            cmd.Parameters.AddWithValue("@atendimento_id", ficha.atendimento_id);
            cmd.Parameters.AddWithValue("@status", ficha.status);

            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na atualização de Ficha");
            }
            finally
            {
                conexao.Close();
            }
        }

        public void Delete(MODEL.Ficha_Vet ficha)
        {
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Delete from Ficha_Vet where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", ficha.id);
            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na Remoção de Ficha");
            }
            finally
            {
                conexao.Close();
            }

        }
    }
}
