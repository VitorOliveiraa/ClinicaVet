﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO.Camadas.DAL
{
    public class Cliente
    {
        private string strCon = Conexao.getConexao();

        public List<MODEL.Cliente_Vet> Select()
        {
            List<MODEL.Cliente_Vet> lstCliente = new List<MODEL.Cliente_Vet>();

            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Select * from Cliente_Vet";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            conexao.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    MODEL.Cliente_Vet cliente = new MODEL.Cliente_Vet();
                    cliente.id = Convert.ToInt32(reader[0].ToString());
                    cliente.nome = reader["nome"].ToString();
                    cliente.cpf = Convert.ToDecimal(reader["cpf"].ToString());
                    cliente.fone = Convert.ToDecimal(reader["fone"].ToString());
                    cliente.endereco = reader["endereco"].ToString();
                    cliente.cidade = reader["cidade"].ToString();
                    lstCliente.Add(cliente);




                }
            }
            catch
            {
                Console.WriteLine("Erro na Seleção de Clientes");

            }
            finally
            {
                conexao.Close();
            }


            return lstCliente;

        }

        public List<MODEL.Cliente_Vet> SelectById(int id)
        {
            List<MODEL.Cliente_Vet> lstCliente = new List<MODEL.Cliente_Vet>();
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Select * from Cliente_Vet where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", id);
            conexao.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    MODEL.Cliente_Vet cliente = new MODEL.Cliente_Vet();
                    cliente.id = Convert.ToInt32(reader[0].ToString());
                    cliente.nome = reader["nome"].ToString();
                    cliente.cpf = Convert.ToDecimal(reader["cpf"].ToString());
                    cliente.fone = Convert.ToDecimal(reader["fone"].ToString());
                    cliente.endereco = reader["endereco"].ToString();
                    cliente.cidade = reader["cidade"].ToString();
                    lstCliente.Add(cliente);
                }
            }
            catch
            {
                Console.WriteLine("Deu erro na Seleção de Clientes por ID...");
            }
            finally
            {
                conexao.Close();
            }

            return lstCliente;
        }

        public List<MODEL.Cliente_Vet> SelectByNome(string nome)
        {
            List<MODEL.Cliente_Vet> lstCliente = new List<MODEL.Cliente_Vet>();
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Select * from Cliente_Vet where (nome like @nome);";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@nome", nome.Trim() + "%");
            conexao.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    MODEL.Cliente_Vet cliente = new MODEL.Cliente_Vet();
                    cliente.id = Convert.ToInt32(reader[0].ToString());
                    cliente.nome = reader["nome"].ToString();
                    cliente.cpf = Convert.ToDecimal(reader["cpf"].ToString());
                    cliente.fone = Convert.ToDecimal(reader["fone"].ToString());
                    cliente.endereco = reader["endereco"].ToString();
                    cliente.cidade = reader["cidade"].ToString();
                    lstCliente.Add(cliente);
                }
            }
            catch
            {
                Console.WriteLine("Deu erro na Seleção de Clientes por Nome...");
            }
            finally
            {
                conexao.Close();
            }

            return lstCliente;
        }

        public void Insert(MODEL.Cliente_Vet cliente)
        {

            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Insert into Cliente_Vet values(@nome, @cpf, @fone, @endereco, @cidade);";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@nome", cliente.nome);
            cmd.Parameters.AddWithValue("@cpf", cliente.cpf);
            cmd.Parameters.AddWithValue("@fone", cliente.fone);
            cmd.Parameters.AddWithValue("@endereco", cliente.endereco);
            cmd.Parameters.AddWithValue("@cidade", cliente.cidade);
            conexao.Open();

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na seleção de Cliente");

            }


            finally
            {
                conexao.Close();
            }

        }

        public void Update(MODEL.Cliente_Vet cliente)
        {
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Update Cliente_Vet set nome=@nome, ";
            sql += " cpf=@cpf, fone=@fone, ";
            sql += " endereco=@endereco, cidade=@cidade ";
            sql += " where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", cliente.id);
            cmd.Parameters.AddWithValue("@nome", cliente.nome);
            cmd.Parameters.AddWithValue("@cpf", cliente.cpf);
            cmd.Parameters.AddWithValue("@fone", cliente.fone);
            cmd.Parameters.AddWithValue("@endereco", cliente.endereco);
            cmd.Parameters.AddWithValue("@cidade", cliente.cidade);
            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na atualização de Clientes");
            }
            finally
            {
                conexao.Close();
            }

        }

        public void Delete(MODEL.Cliente_Vet cliente)
            {
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Delete from Cliente_Vet where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", cliente.id);
            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na Remoção de Clientes");
            }
            finally
            {
                conexao.Close();
            }

        }

    }
}