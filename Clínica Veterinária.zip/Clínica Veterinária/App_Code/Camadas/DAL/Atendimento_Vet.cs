﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO.Camadas.DAL
{
    public class Atendimento_Vet
    {
        private string strCon = Conexao.getConexao();

        public List<MODEL.Atendimento_Vet> Select()
        {
            List<MODEL.Atendimento_Vet> lstatendimento = new List<MODEL.Atendimento_Vet>();
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Select * from Atendimento_Vet";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            conexao.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    MODEL.Atendimento_Vet atendimento = new MODEL.Atendimento_Vet();
                    atendimento.id = Convert.ToInt32(reader[0].ToString());
                    atendimento.animal_id = Convert.ToInt32(reader["animal_id"].ToString());
                    atendimento.data = Convert.ToDateTime(reader["data"].ToString());

                    lstatendimento.Add(atendimento);
                }
            }
            catch
            {
                Console.WriteLine("Deu erro na Seleção de Atendimento...");
            }
            finally
            {
                conexao.Close();
            }

            return lstatendimento;
        }

        public void Insert(MODEL.Atendimento_Vet atendimento)
        {
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Insert into Atendimento_Vet values (@animal_id, @data);";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@animal_id", atendimento.animal_id);
            cmd.Parameters.AddWithValue("@data", atendimento.data);

            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Deu erro na inserção de Atendimento...");
            }
            finally
            {
                conexao.Close();
            }
        }
            public void Update(MODEL.Atendimento_Vet atendimento)
        {
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Update Atendimento_Vet set animal_id=@animal_id, ";
            sql += " data=@data where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", atendimento.id);
            cmd.Parameters.AddWithValue("@animal_id", atendimento.animal_id);
            cmd.Parameters.AddWithValue("@data", atendimento.data);

            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na atualização de Atendimento");
            }
            finally
            {
                conexao.Close();
            }

        }
        public void Delete(MODEL.Atendimento_Vet atendimento)
        {
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Delete from Atendimento_Vet where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", atendimento.id);
            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na Remoção de Atendimento");
            }
            finally
            {
                conexao.Close();
            }

        }
    }
   }

