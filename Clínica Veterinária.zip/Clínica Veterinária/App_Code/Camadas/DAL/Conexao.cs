﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO.Camadas.DAL
{
    public class Conexao
    {
        public static string getConexao()
        {
            return @"Data Source=VITÃO\SQLEXPRESS;Initial Catalog=VETERINARIO;Integrated Security=True";
            
        }
    }
}
