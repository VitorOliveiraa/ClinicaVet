﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO.Camadas.DAL
{
    public class Animais
    {
        private string strCon = Conexao.getConexao();

        public List<MODEL.Animal_Vet> Select()
        {
            List<MODEL.Animal_Vet> lstAnimal = new List<MODEL.Animal_Vet>();

            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Select * from Animal_Vet";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            conexao.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    MODEL.Animal_Vet animal = new MODEL.Animal_Vet();
                    animal.id = Convert.ToInt32(reader[0].ToString());
                    animal.nome = reader["nome"].ToString();
                    animal.idade = Convert.ToInt32(reader["idade"].ToString());
                    animal.raca = reader["raca"].ToString();
                    animal.cor = reader["cor"].ToString();
                    animal.peso = Convert.ToDecimal(reader["peso"].ToString());

                    lstAnimal.Add(animal);




                }
            }
            catch
            {
                Console.WriteLine("Erro na Seleção de Animais");

            }
            finally
            {
                conexao.Close();
            }


            return lstAnimal;

        }

        public List<MODEL.Animal_Vet> SelectById(int id)
        {
            List<MODEL.Animal_Vet> lstAnimal = new List<MODEL.Animal_Vet>();
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Select * from Animal_Vet where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", id);
            conexao.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    MODEL.Animal_Vet animal = new MODEL.Animal_Vet();
                    animal.id = Convert.ToInt32(reader[0].ToString());
                    animal.nome = reader["nome"].ToString();
                    animal.idade = Convert.ToInt32(reader["idade"].ToString());
                    animal.raca = reader["raca"].ToString();
                    animal.cor = reader["cor"].ToString();
                    animal.peso = Convert.ToDecimal (reader["peso"].ToString());
                    lstAnimal.Add(animal);
                }
            }
            catch
            {
                Console.WriteLine("Deu erro na Seleção de Animais por ID...");
            }
            finally
            {
                conexao.Close();
            }

            return lstAnimal;
        }

        public List<MODEL.Animal_Vet> SelectByNome(string nome)
        {
            List<MODEL.Animal_Vet> lstAnimal = new List<MODEL.Animal_Vet>();
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Select * from Animal_Vet where (nome like @nome);";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@nome", nome.Trim() + "%");
            conexao.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    MODEL.Animal_Vet animal = new MODEL.Animal_Vet();
                    animal.id = Convert.ToInt32(reader[0].ToString());
                    animal.nome = reader["nome"].ToString();
                    animal.idade = Convert.ToInt32(reader["idade"].ToString());
                    animal.raca = reader["raca"].ToString();
                    animal.cor = reader["cor"].ToString();
                    animal.peso = Convert.ToDecimal(reader["peso"].ToString());
                    lstAnimal.Add(animal);
                }
            }
            catch
            {
                Console.WriteLine("Deu erro na Seleção de Clientes por Nome...");
            }
            finally
            {
                conexao.Close();
            }

            return lstAnimal;
        }

        public void Insert(MODEL.Animal_Vet animal)
        {

            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Insert into Animal_Vet values(@nome, @idade, @raca, @cor, @peso);";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@nome", animal.nome);
            cmd.Parameters.AddWithValue("@idade", animal.idade);
            cmd.Parameters.AddWithValue("@raca", animal.raca);
            cmd.Parameters.AddWithValue("@cor", animal.cor);
            cmd.Parameters.AddWithValue("@peso", animal.peso);
            conexao.Open();

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na seleção de Animais");

            }


            finally
            {
                conexao.Close();
            }
        }

        public void Update(MODEL.Animal_Vet animal)
        {
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Update Animal_Vet set nome=@nome, ";
            sql += " idade=@idade, raca=@raca, ";
            sql += " cor=@cor, peso=@peso ";
            sql += " where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", animal.id);
            cmd.Parameters.AddWithValue("@nome", animal.nome);
            cmd.Parameters.AddWithValue("@idade", animal.idade);
            cmd.Parameters.AddWithValue("@raca", animal.raca);
            cmd.Parameters.AddWithValue("@cor", animal.cor);
            cmd.Parameters.AddWithValue("@peso", animal.peso);
            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na atualização de Animais");
            }
            finally
            {
                conexao.Close();
            }
        }

        public void Delete(MODEL.Animal_Vet animal)
        {
            SqlConnection conexao = new SqlConnection(strCon);
            string sql = "Delete from Animal_Vet where id=@id;";
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.Parameters.AddWithValue("@id", animal.id);
            conexao.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("Erro na Remoção de Animais");
            }
            finally
            {
                conexao.Close();
            }
         }
       }
}
